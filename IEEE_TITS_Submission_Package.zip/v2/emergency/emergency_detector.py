class EmergencyDetector:
    pass