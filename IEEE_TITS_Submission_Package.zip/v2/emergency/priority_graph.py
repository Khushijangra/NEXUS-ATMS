class PriorityGraph:
    pass