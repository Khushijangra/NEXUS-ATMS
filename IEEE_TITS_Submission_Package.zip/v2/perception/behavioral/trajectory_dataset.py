class TrajectoryDataset:
    pass